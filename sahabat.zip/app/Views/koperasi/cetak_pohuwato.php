<?=$cetak['nama_pemilik']?>
