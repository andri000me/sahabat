<?= $this->extend('layout/templatel') ?>
<?= $this->section('content'); ?>
<!-- Jumbotron -->
<div class="container-fluid mt-5">
    <div class="jumbotron text-center" style="margin-bottom:500px;">

        <!-- Title -->
        <h2 class=" card-title h2 wow fadeInLeft">Permohonan Pertimbangan Teknis Izin Penyelenggaraan Angkutan Orang Dalam Trayek AKDP</h2>
        <!-- Subtitle -->
        <p class="blue-text my-4 font-weight-bold wow fadeInLeft">DINAS PERHUBUNGAN PROVINSI GORNTALO</p>

        <!-- Grid row -->
        <div class="row d-flex justify-content-center wow fadeInLeft">

            <!-- Grid column -->
            <div class="col-xl-7 pb-2">

                <!-- <p class="card-text wow fadeInLeft">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fuga aliquid dolorem ea distinctio exercitationem delectus qui, quas eum architecto, amet quasi accusantium, fugit consequatur ducimus obcaecati numquam molestias hic itaque accusantium doloremque laudantium, totam rem aperiam.</p> -->

            </div>
            <!-- Grid column -->

        </div>
        <!-- Grid row -->

        <hr class="my-4">

        <div class="pt-2"">
        <a href="/rekomendasi/step1/" type=" button" class="btn btn-blue waves-effect wow fadeInLeft">Pengurusan Baru</a>
            <a href="/rekomendasi/step1p/" type="button" class="btn btn-outline-primary waves-effect wow fadeInLeft">Perpanjangan</a>
        </div>

    </div>
    <!-- Jumbotron -->
    <?= $this->endSection(); ?>